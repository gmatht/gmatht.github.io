use std::collections::HashMap;
use std::io::{self};
use std::io::{stdin, Read};
//extern crate dont_disappear;

fn format_cents(cents: &i32) -> String {
    let dollars = cents / 100;
    let remaining_cents = cents % 100;
    format!("{dollars}.{remaining_cents}")
}

fn cleanline (line: &str) -> String {
    let (first_part, second_part) = line.split_at(2);
    first_part.replace("$","")+second_part
}

fn main()  -> io::Result<()> { let num_str = std::fs::read_to_string("transactions.txt")?;

    let mut positive_elements: Vec<i32> = Vec::new();
    let mut negative_elements: Vec<i32> = Vec::new();
    let mut full_text: HashMap<i32, &str> = HashMap::new();

    for line in num_str.lines() {
        if let Some(c) = line.chars().nth(1) {
            if c.is_whitespace() {
                continue;
            }
        } else {
            continue;
        }
        let mut words = line.split_whitespace();

        if let Some(first_word) = words.next() {
            if first_word.contains("/") {
                continue
            }
            let cents = parse_cents(first_word);
            if cents == 0 {
                continue;
            }
            full_text.insert(cents, line);
            if cents>0 {
              positive_elements.push(cents)
            } else {
              negative_elements.push(cents)
            }
        } else {
            println!("No words found!");
        }

    }

let mut receipts: Vec<_>=negative_elements.iter().map(|&x| -x).collect();

positive_elements.sort();
receipts.sort();

for i in 1..9 {
    let mut j=0;
    while j < positive_elements.len() {
        let sum=positive_elements[j];
        let found = find_subset_sum(&receipts, sum, i);
        match found {
            Some(v) => {
                print!("## {}",format_cents(&sum));
                for cents in &v {
                    print!("-{}",format_cents(cents));
                }
                println!("=0 ##");
                if let Some(t) = full_text.get(&sum) {
                    println!("{}", cleanline(t));
                }
                positive_elements.remove(j);
                for cents in v {
                    if let Some(index) = receipts.iter().position(|&x| x == cents) {
                        receipts.remove(index);
                    }
                
                    if let Some(t) = full_text.get(&-cents) {
                        println!("{}", cleanline(t));
                    }
                }
                
                println!("");
                continue;
                },
            None => {}
        }
        j=j+1;
    }
}
println!("");
println!("UNMATCHED REIMBURSEMENTS");
for cents in positive_elements {
    if let Some(t) = full_text.get(&cents) {
        println!("{}", cleanline(t));
    }
}

println!("");
println!("");

println!("UNMATCHED RECEIPTS");
for cents in receipts {
    if let Some(t) = full_text.get(&-cents) {
        println!("{}", cleanline(t));
    }
}


println!("");


//dont_disappear::any_key_to_continue::default();
//let mut stdin   = io::stdin();
//let _ = stdin.read(&mut [0u8]).unwrap();

stdin().read(&mut [0]).unwrap();

Ok(()) }

fn parse_cents(input: &str) -> i32 {
    let parts: Vec<&str> = input.trim().split('.').collect();

     // Parse dollars and cents
    let dollarpart=parts.get(0).unwrap_or(&"").replace(&"$","");
    let nominus = dollarpart.clone().replace("-","");
    let ispositive = dollarpart == nominus;

    let dollars: i32 = match nominus.parse() {      
            Ok(num) => num,
            Err(_) => {
                println!("Invalid input for dollars. '{}'", input);
                return 0;
            }
    };

    let cents: i32 = match parts.get(1) {
        Some(&c) => {
            let cc = if c.len() < 2 {
                format!("{}0", c)
            } else {
                c.to_string()
            };
            match cc[..2].parse() {
                Ok(num) => num,
                Err(_) => {
                    println!("Invalid input for cents.");
                    return 0;
                }
            }
        }
        None => {
            // If cents part is missing, assume it's 0
            0
        }
    };

    let total_cents = dollars * 100 + cents;
    let total = if ispositive {total_cents} else {-total_cents};

    return total;
}

fn find_subset_sum(vector: &Vec<i32>, target_sum: i32, subset_size: usize) -> Option<Vec<i32>> {
    let mut current_subset = vec![];
    let mut result = None;

    // Recursive function to find subsets
    fn backtrack(
        vector: &Vec<i32>,
        target_sum: i32,
        subset_size: usize,
        current_subset: &mut Vec<i32>,
        result: &mut Option<Vec<i32>>,
        start_index: usize,
        sum_so_far: i32,
    ) {
        if current_subset.len() == subset_size {
            if sum_so_far == target_sum {
                *result = Some(current_subset.clone());
            }
            return;
        }

        for i in start_index..vector.len() {
            if sum_so_far + vector[i] <= target_sum {
                current_subset.push(vector[i]);
                backtrack(
                    vector,
                    target_sum,
                    subset_size,
                    current_subset,
                    result,
                    i + 1,
                    sum_so_far + vector[i],
                );
                current_subset.pop();
            } else {
                //assume sorted
                break;
            }
        }
    }

    backtrack(vector, target_sum, subset_size, &mut current_subset, &mut result, 0, 0);
    result
}
